[![Build Status](https://travis-ci.org/moose/moose.png?branch=master,stable/2.08)](https://travis-ci.org/moose/moose)

Moose
=====

Moose is a postmodern object system for Perl 5.

Moose on CPAN: [https://metacpan.org/release/Moose]
