package Moose::Meta::Attribute::Custom::Trait::Foo;

use Moose::Role;

1;
